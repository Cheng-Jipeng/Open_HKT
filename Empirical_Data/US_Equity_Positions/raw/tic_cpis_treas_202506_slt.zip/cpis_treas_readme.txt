cpis_treas_readme.txt

The files in the zip file cpis_treas_yyyymm.zip contain data on the sectoral
breakdown of private U.S. cross-border securities claims on foreign residents.

Data for year-end files come from Treasury International Capital (TIC) annual
reports on U.S. residents’ portfolio holdings of foreign securities (TIC forms
SHC/SHCA – Securities Holdings Claims (Annual)). Data for mid-year files combine
data from TIC forms SHC/SHCA with monthly data from TIC form SLT (Securities
Long Term).

A subset of the data shown here is published by the IMF as part of the CPIS
(Coordinated Portfolio Investment Survey).

The files are in tab-delimited text format and report data by sector of foreign
issuer and U.S. holder.

The files below report the data for private cross-border securities claims.

The files named cpis_treas_yyyymm_6_[num]_grid.txt show data for selected
countries with significant positions, in table format. The files named
cpis_treas_yyyymm_6_[num].txt contain data for the same countries, but in a
single row.

If "slt" is in the file name it indicates if the file was produced with monthly
form SLT data (such as June or preliminary December data prior to the release of
the same year’s SHC annual survey publication). The absence of "slt" indicates
that data are from the annual survey, form SHC.


File                               Description
----                               -----------
3_1.txt                            Equity Securities by Sector of Resident Holder
3_2_1.txt                          Debt Securities, Long-Term by Sector of Resident Holder
3_2_2.txt                          Debt Securities, Short-Term by Sector of Resident Holder
5_1.txt                            Equity Securities by Sector of Nonresident Issuer
5_2_1.txt                          Debt Securities, Long-Term by Sector of Nonresident Issuer
5_2_2.txt                          Debt Securities, Short-Term by Sector of Nonresident Issuer
6_1.txt                            Equity Securities by Sector of Resident Holder, and Economy and Sector of Nonresident Issuer for Specified Economies
6_2_1.txt                          Debt Securities, Long-Term Securities by Sector of Resident Holder, and Economy and Sector of Nonresident Issuer for Specified Economies
6_2_2.txt                          Debt Securities, Short-Term by Sector of Resident Holder, and Economy and Sector of Nonresident Issuer for Specified Economies
cpis_treas_[date]_6_grid.txt       Sum of 6_1.txt, 6_2_1.txt, and 6_2_2.txt with descriptive header
cpis_treas_[date]_6_1.txt          Same as cpis_treas_[date]_6_1_grid.txt, but in single row form
cpis_treas_[date]_6_1_grid.txt     Same as 6_1.txt with descriptive header
cpis_treas_[date]_6_2_1.txt        Same as cpis_treas_[date]_6_2_1_grid.txt, but in single row form
cpis_treas_[date]_6_2_1_grid.txt   Same as 6_2_1.txt with descriptive header
cpis_treas_[date]_6_2_2.txt        Same as cpis_treas_[date]_6_2_2_grid.txt, but in single row form
cpis_treas_[date]_6_2_2_grid.txt   Same as 6_2_2.txt with descriptive header
